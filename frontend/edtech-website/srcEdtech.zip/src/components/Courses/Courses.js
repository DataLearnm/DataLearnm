import React from 'react';
import './Courses.css';
import { Link } from "react-router-dom";

function Courses() {
  return (
    <div className="courses-container">
      <h1 className="courses-title">Our Courses</h1>
      <div className="courses-list">
        <div className="course-item">
          <Link to="/courses/data-analysis" style={{ textDecoration: 'none', color: 'inherit' }}>
            <h3>📊 Data Analysis</h3>
            <p>Master tools like Excel, SQL, and Tableau to analyze and interpret data effectively.</p>
          </Link>
        </div>
        
        <div className="course-item">
          <Link to="/courses/machine-learning" style={{ textDecoration: 'none', color: 'inherit' }}>
            <h3>🤖 Machine Learning</h3>
            <p>Understand algorithms and build models using Python, TensorFlow, and scikit-learn.</p>
            </Link>
        </div>
        
        <div className="course-item">
          <Link to="/courses/artificial-intelligence" style={{ textDecoration: 'none', color: 'inherit' }}>
            <h3>🧠 Artificial Intelligence</h3>
            <p>Dive into AI concepts, including neural networks, natural language processing, and computer vision.</p>
            </Link>
        </div> 
        
        <div className="course-item">
          <Link to="/courses/cloud-computing" style={{ textDecoration: 'none', color: 'inherit' }}>
            <h3>☁️ Cloud Computing</h3>
            <p>Learn cloud platforms like AWS, Azure, and Google Cloud to design and deploy scalable applications.</p>
            </Link>
        </div>  
        
        <div className="course-item">
        <Link to="/courses/generative-ai" style={{ textDecoration: 'none', color: 'inherit' }}>
          <h3>✨ Generative AI</h3>
          <p>Explore cutting-edge technologies like ChatGPT, Stable Diffusion, and DALL·E to create AI-driven content.</p>
          </Link>
        </div> 
        

        <div className="course-item">
          <h3>💻 Web Development</h3>
          <p>Learn HTML, CSS, JavaScript, and frameworks like React and Angular.</p>
        </div>
        <div className="course-item">
          <h3>📱 Mobile App Development</h3>
          <p>Build cross-platform mobile apps using Flutter or React Native.</p>
        </div> 
        <div className="course-item">
          <Link to="/courses/data-science" style={{ textDecoration: 'none', color: 'inherit' }}>
            <h3>📊 Data Science</h3>
            <p>Dive into data manipulation, visualization, and predictive modeling with Python, R, and tools like Pandas and Matplotlib.</p>
            </Link>
        </div>
      </div>
    </div>
  );
}

export default Courses;
