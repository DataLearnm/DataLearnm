import React from 'react';
import './Home.css';
import MainSection from '../MainSection/MainSection';

function Home() {
  return (
    <div className="home-container">
      <MainSection/>
    </div>
  );
}

export default Home;
