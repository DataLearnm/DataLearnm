import React, { useState } from "react";
import "./Navbar.css";
import { NavLink, Link } from "react-router-dom";

function Navbar() {
  const [isDropdownVisible, setDropdownVisible] = useState(false);

  const handleMouseEnter = () => {
    setDropdownVisible(true);
  };

  const handleMouseLeave = () => {
    setTimeout(() => {
      setDropdownVisible(false);
    }, 3000); // Dropdown will hide after 3 seconds
  };

  return (
    <nav className="navbar">
      <div className="logo">DataLearnm</div>
      <ul className="nav-links">
        <li>
          <NavLink to="/" exact="true" activeClassName="active">
            Home
          </NavLink>
        </li>
        <li>
          <NavLink to="/about-us" exact="true" activeClassName="active">
            About Us
          </NavLink>
        </li>

        <li
        className="dropdown"
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
      >
        <NavLink to="/services" exact="true" activeClassName="active">
          Service
        </NavLink>
        {isDropdownVisible && (
          <ul className="dropdown-menu">
            <li>
              <Link to="/services/online-live-sessions">Online Live Sessions</Link>
            </li>
            <li>
              <Link to="/services/assignments">Assignments on Each Topic</Link>
            </li>
            <li>
              <Link to="/services/mock-interviews">Mock Interviews</Link>
            </li>
            <li>
              <Link to="/services/industry-projects"> Industry-Oriented Projects</Link>
            </li>
            <li>
              <Link to="/services/placement-assistence">Placement Assistance</Link>
            </li>
          </ul>
        )}
      </li>
        {/*<li>
          <NavLink to="/services" exact="true" activeClassName="active">
            Services
          </NavLink>
        </li>*/}
        <li
          className="dropdown"
          onMouseEnter={handleMouseEnter}
          onMouseLeave={handleMouseLeave}
        >
          <NavLink to="/courses" exact="true" activeClassName="active">
            Courses
          </NavLink>
          {isDropdownVisible && (
            <ul className="dropdown-menu">
              <li>
                <Link to="/courses/data-science">Data Science</Link>
              </li>
              <li>
                <Link to="/courses/machine-learning">Machine Learning</Link>
              </li>
              <li>
                <Link to="/courses/data-analysis">Data Analysis</Link>
              </li>
              <li>
                <Link to="/courses/artificial-intelligence">
                  Artificial Intelligence
                </Link>
              </li>
              <li>
                <Link to="/courses/cloud-computing">Cloud Computing</Link>
              </li>
              <li>
              <Link to="/courses/generative-ai">Generative AI</Link>
            </li>
            </ul>
          )}
        </li>
        <li>
        <NavLink to="/contact-us" exact="true" activeClassName="active">
          ContactUs
        </NavLink>
        </li>

        <li>Blog</li>
        <li>
          <Link to="/login">
            <button className="register-button">Login</button>
          </Link>
        </li>
      </ul>
    </nav>
  );
}

export default Navbar;
