import React from 'react';
import { useNavigate } from 'react-router-dom';  
import './Assignments.css';

const Assignments = () => {
  const navigate = useNavigate();  

  const handleBackClick = () => {
    navigate('/');  
  };

  return (
    <div className="assignments-page">
      {/* Hero Section */}
      <div className="hero-section">
        <div className="hero-content">
          <div className="text-container">
            <h1>Assignments</h1>
          </div>
          
          <div className="card-container">
            <div className="card">
              <h3>Get Started with Assignments</h3>
              <p>Start working on assignments that will boost your learning experience.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="content">
        {/* Heading and paragraph section */}
        <div className="heading-paragraph">
            <div className="full-width-container">
                <h1>Assignments On Each Topic</h1>
                <p>
                At Datalearnm, we provide a comprehensive set of assignments for each topic
                covered in our courses. These assignments are carefully crafted to help you
                solidify your understanding and apply the knowledge gained during the live sessions.
                </p>
            </div>
        </div>

        {/* Assignments Container */}
        <div className="assignments-container">
          {/* Topics Covered */}
          <section className="topics-covered" style={{marginTop:'550px'}}>
            <h2>Examples of Topics Covered</h2>
            <div className="topics-cards">
              <div className="card">Introduction to Programming</div>
              <div className="card">Data Structures and Algorithms</div>
              <div className="card">Web Development Fundamentals</div>
              <div className="card">Database Management Systems</div>
              <div className="card">Cloud Computing Basics</div>
            </div>
          </section>

          {/* Why Assignments are Essential */}
          <section className="assignment-benefits" style={{marginLeft:'-20%'}}>
            <h2>Why Assignments are Essential</h2>
            <ul className="highlight-list">
              <li>Practical Learning: Apply concepts to practical problems and projects.</li>
              <li>Skill Enhancement: Strengthen your technical and problem-solving skills.</li>
              <li>Portfolio Building: Work on projects that you can showcase in your portfolio.</li>
              <li>Confidence Boost: Develop confidence in tackling real-world challenges.</li>
            </ul>
          </section>

          {/* Assignment Highlights */}
          <div className="cards-container" style={{marginLeft:'-25%'}}>
            {[ 
              {
                title: "Hands-On Practice",
                description: "Our assignments ensure you can apply the concepts learned in real-world scenarios."
              },
              {
                title: "Personalized Feedback",
                description: "Receive detailed feedback to refine your skills and improve consistently."
              },
              {
                title: "Time Management",
                description: "Manage your time effectively while balancing learning with other commitments."
              },
              {
                title: "Real-World Projects",
                description: "Gain hands-on experience and build a portfolio to showcase to potential employers."
              }
            ].map((card, index) => (
              <div key={index} className="card">
                <h2>{card.title}</h2>
                <p>{card.description}</p>
              </div>
            ))}
          </div>

          {/* Guidance and Support */}
          <section className="guidance-section" style={{marginLeft:'-40%'}}>
            <h2>Guidance and Support</h2>
            <p>
              Our experienced instructors are always available to guide you. Participate in live Q&A
              sessions and one-on-one mentorship for personalized support.
            </p>
          </section>

          {/* Additional Resources */}
          <section className="additional-resources" style={{marginLeft:'-20%'}}>
            <h2>Additional Resources</h2>
            <ul>
              <li>Documentation and tutorials for advanced topics</li>
              <li>Interactive platforms for practicing skills</li>
              <li>Webinars and guest lectures by industry experts</li>
              <li>Community forums for peer learning and collaboration</li>
            </ul>
          </section>
        </div>
      </main>

      {/* Back to Home Button */}
      <div className="back-button-container">
        <button onClick={handleBackClick} className="back-button">Back to Home</button>
      </div>
    </div>
  );
};

export default Assignments;
