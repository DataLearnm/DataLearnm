import React from 'react';
import { useNavigate } from 'react-router-dom';
import './OnlineLiveSessions.css';

const OnlineLiveSessions = () => {
  const navigate = useNavigate();

  const handleSignUpClick = () => {
    navigate('/register');
  };

  return (
    <div className="online-sessions-container">
      <h1 className="page-heading">Online Live Sessions</h1>
      
      <section className="intro-section">
        <p>
          Welcome to Datalearn's Online Live Sessions! We offer over 150+ hours of interactive live sessions
          with experienced instructors, providing in-depth coverage of the following courses:
        </p>
        <ul className="card-list">
          <li className="card-item">Data Science</li>
          <li className="card-item">Machine Learning</li>
          <li className="card-item">Data Analysis</li>
          <li className="card-item">Artificial Intelligence</li>
          <li className="card-item">Cloud Computing</li>
          <li className="card-item">Generative AI</li>
        </ul>
      </section>

      <section className="course-videos">
        <h2>Course Preview Videos</h2>
        <div className="video-container">
          <div className="video-item">
            <h3>Introduction to Data Science</h3>
            <iframe
              width="560"
              height="315"
              src="https://www.youtube.com/embed/RBSUwFGa6Fk"
              title="Data Science Intro"
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            ></iframe>
            <p>Get an overview of the Data Science course and learn the basics of data processing and analysis.</p>
          </div>
          <div className="video-item">
            <h3>Machine Learning Overview</h3>
            <iframe
              width="560"
              height="315"
              src="https://www.youtube.com/embed/ukzFI9rgwfU"
              title="Machine Learning Intro"
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            ></iframe>
            <p>Explore the foundations of Machine Learning and understand key algorithms.</p>
          </div>
          <div className="video-item">
            <h3>Data Analysis Fundamentals</h3>
            <iframe
              width="560"
              height="315"
              src="https://www.youtube.com/embed/yZvFH7B6gKI?start=5"
              title="Artificial Intelligence Intro"
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            ></iframe>
            <p>Learn the basics of Artificial Intelligence and its applications in real-world scenarios.</p>
          </div>
          <div className="video-item">
            <h3>Artificial Intelligence Overview</h3>
            <iframe
              width="560"
              height="315"
              src="https://www.youtube.com/embed/Yq0QkCxoTHM?start=40"
              title="Data Analysis Intro"
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            ></iframe>
            <p>Understand the importance of data analysis in decision-making and how to work with datasets.</p>
          </div>
        </div>
      </section>

      <section className="course-description">
        <h2>Course Details</h2>
        <p>
          Datalearn's Online Live Sessions are designed to help you master each concept with interactive
          sessions and real-world assignments. Our instructors are industry experts with years of experience
          in their respective fields. Whether you're interested in Data Science, Machine Learning, or Artificial Intelligence,
          our hands-on approach will give you the skills to succeed in your career.
        </p>
      </section>
      
      <section className="cta-section">
        <h2>Get Started with Datalearn</h2>
        <p>Ready to take the next step in your career? Join our online live sessions and begin your journey to success!</p>
        <button className="cta-button" onClick={handleSignUpClick}>Sign Up Now</button>
      </section>
    </div>
  );
};

export default OnlineLiveSessions;
