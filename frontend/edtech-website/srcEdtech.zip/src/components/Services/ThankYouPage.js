import React from "react";
import "./ThankYouPage.css"; 

const ThankYouPage = () => {
  return (
    <div className="thank-you-page">
      <div className="thank-you-container">
        <h1>Thank You!</h1>
        <p>Your interview request has been submitted successfully.</p>
        <div className="button-container">
          <button onClick={() => window.location.href = '/'}>Go Back to Home</button>
        </div>
      </div>
    </div>
  );
};

export default ThankYouPage;
