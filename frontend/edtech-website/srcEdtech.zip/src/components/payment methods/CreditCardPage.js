import React from 'react';
import './CreditCardPage.css';

const CreditCardPage = () => {
  return (
    <div className="payment-page">
      <h2>Credit Card Payment</h2>
      <p>Please enter your credit card details below to complete the payment.</p>
      
      <form className="payment-form">
        <div className="form-group">
          <label htmlFor="cardNumber">Card Number:</label>
          <input type="text" id="cardNumber" placeholder="Enter your card number" required />
        </div>
        <div className="form-group">
          <label htmlFor="expiryDate">Expiry Date:</label>
          <input type="text" id="expiryDate" placeholder="MM/YY" required />
        </div>
        <div className="form-group">
          <label htmlFor="cvv">CVV:</label>
          <input type="text" id="cvv" placeholder="Enter CVV" required />
        </div>
        <div className="form-group">
          <button type="submit" className="submit-button">Pay Now</button>
        </div>
      </form>
    </div>
  );
};

export default CreditCardPage;
